package com.giksgik.perimeterdefense.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CombatEngineTest {
    private fun group(color: AmmoColor, size: Int = 3) = MatchGroup(
        ammoColor = color,
        cells = (0 until size).map { 0 to it }.toSet()
    )

    private fun enemy(
        id: Long = 1L,
        type: EnemyType = EnemyType.SCOUT,
        lane: Int = 2,
        progress: Int = 3,
        health: Int = 20,
        maxHealth: Int = health,
        attackDamage: Int = 10,
        rewardChips: Int = 25,
        slowTurns: Int = 0
    ) = EnemyUnit(id, type, lane, progress, health, maxHealth, attackDamage, rewardChips, slowTurns)

    @Test
    fun redMatchDamagesMostAdvancedEnemyAndAwardsChipsOnKill() {
        val state = CombatState(enemies = listOf(
            enemy(id = 1L, progress = 1, health = 20),
            enemy(id = 2L, progress = 4, health = 20, rewardChips = 40)
        ))

        val result = CombatEngine.resolveMatches(state, listOf(group(AmmoColor.RED)))

        assertEquals(listOf(1L), result.state.enemies.map { it.id })
        assertEquals(40, result.state.chips)
        assertTrue(result.events.any { it.type == CombatEventType.ENEMY_DESTROYED && it.enemyId == 2L })
    }

    @Test
    fun fourCellRedMatchUsesOnePointFiveDamageMultiplier() {
        val state = CombatState(enemies = listOf(enemy(health = 50, maxHealth = 50)))

        val result = CombatEngine.resolveMatches(state, listOf(group(AmmoColor.RED, size = 4)))

        assertEquals(5, result.state.enemies.single().health)
    }

    @Test
    fun blueMatchSlowsSurvivingEnemy() {
        val state = CombatState(enemies = listOf(enemy(health = 50, maxHealth = 50)))

        val result = CombatEngine.resolveMatches(state, listOf(group(AmmoColor.BLUE)))

        assertEquals(36, result.state.enemies.single().health)
        assertEquals(2, result.state.enemies.single().slowTurns)
        assertTrue(result.events.any { it.type == CombatEventType.ENEMY_SLOWED })
    }

    @Test
    fun yellowMatchDamagesNearbyEnemiesInSameLaneOnly() {
        val state = CombatState(enemies = listOf(
            enemy(id = 1L, lane = 2, progress = 4, health = 50, maxHealth = 50),
            enemy(id = 2L, lane = 2, progress = 3, health = 50, maxHealth = 50),
            enemy(id = 3L, lane = 1, progress = 4, health = 50, maxHealth = 50)
        ))

        val result = CombatEngine.resolveMatches(state, listOf(group(AmmoColor.YELLOW)))

        assertEquals(32, result.state.enemies.first { it.id == 1L }.health)
        assertEquals(32, result.state.enemies.first { it.id == 2L }.health)
        assertEquals(50, result.state.enemies.first { it.id == 3L }.health)
    }

    @Test
    fun greenMatchRepairsBaseWithoutExceedingMaximum() {
        val state = CombatState(baseHp = 90, maxBaseHp = 100)

        val result = CombatEngine.resolveMatches(state, listOf(group(AmmoColor.GREEN_HEAL, size = 4)))

        assertEquals(100, result.state.baseHp)
        assertTrue(result.events.any { it.type == CombatEventType.BASE_REPAIRED && it.amount == 10 })
    }

    @Test
    fun slowedEnemyLosesMovementTurnAndEnemyAtBaseDamagesShield() {
        val state = CombatState(baseHp = 30, enemies = listOf(
            enemy(id = 1L, progress = 2, slowTurns = 1),
            enemy(id = 2L, progress = CombatEngine.PATH_LENGTH - 1, attackDamage = 12)
        ))

        val result = CombatEngine.advanceTurn(state)

        assertEquals(18, result.state.baseHp)
        assertEquals(2, result.state.enemies.first { it.id == 1L }.progress)
        assertEquals(0, result.state.enemies.first { it.id == 1L }.slowTurns)
        assertFalse(result.state.isGameOver)
        assertFalse(result.state.enemies.any { it.id == 2L })
    }

    @Test
    fun stunnedTurretsDoNotAttackButGreenStillRepairs() {
        val state = CombatState(
            baseHp = 50,
            turretStunTurns = 2,
            enemies = listOf(enemy(health = 50, maxHealth = 50))
        )

        val result = CombatEngine.resolveMatches(
            state,
            listOf(group(AmmoColor.RED), group(AmmoColor.GREEN_HEAL))
        )

        assertEquals(50, result.state.enemies.single().health)
        assertEquals(65, result.state.baseHp)
        assertTrue(result.events.any { it.type == CombatEventType.TURRETS_STUNNED })
    }

    @Test
    fun newGameCreatesFirstWaveAndEmptyWaveAdvances() {
        val initial = CombatEngine.newGame()
        assertEquals(1, initial.wave)
        assertEquals(3, initial.enemies.size)

        val next = CombatEngine.advanceTurn(initial.copy(enemies = emptyList()))
        assertEquals(2, next.state.wave)
        assertEquals(4, next.state.enemies.size)
    }

    @Test
    fun mineDetonationDamagesBaseAndStunsTurrets() {
        val result = CombatEngine.registerMineDetonation(CombatState(baseHp = 50))

        assertEquals(47, result.state.baseHp)
        assertEquals(1, result.state.turretStunTurns)
    }

    @Test
    fun capturedMineDamagesTheMostAdvancedEnemy() {
        val state = CombatState(enemies = listOf(
            enemy(id = 1L, progress = 1, health = 50, maxHealth = 50),
            enemy(id = 2L, progress = 3, health = 50, maxHealth = 50)
        ))

        val result = CombatEngine.launchCapturedMine(state)

        assertEquals(15, result.state.enemies.first { it.id == 2L }.health)
        assertEquals(50, result.state.enemies.first { it.id == 1L }.health)
    }

    @Test
    fun airstrikeDamagesAllEnemiesAndAwardsOnlyKillRewards() {
        val state = CombatState(chips = 5, enemies = listOf(
            enemy(id = 1L, health = 15, maxHealth = 15, rewardChips = 10),
            enemy(id = 2L, health = 50, maxHealth = 50, rewardChips = 20)
        ))

        val result = CombatEngine.launchAirstrike(state)

        assertEquals(listOf(2L), result.state.enemies.map { it.id })
        assertEquals(15, result.state.enemies.single().health)
        assertEquals(15, result.state.chips)
        assertEquals(1, result.events.count { it.type == CombatEventType.ENEMY_DESTROYED })
    }

    @Test
    fun repairBoosterCapsHealthAtMaximum() {
        val result = CombatEngine.repairBase(CombatState(baseHp = 92, maxBaseHp = 100))

        assertEquals(100, result.state.baseHp)
        assertEquals(8, result.events.single().amount)
    }

    @Test
    fun purchaseUpgradeDeductsChipsAndScalesMortarDamage() {
        val state = CombatState(
            chips = 50,
            enemies = listOf(enemy(health = 50, maxHealth = 50))
        )

        val upgraded = CombatEngine.purchaseUpgrade(state, HangarUpgradeType.MORTAR)
        assertNotNull(upgraded)
        assertEquals(15, upgraded!!.state.chips)
        assertEquals(1, upgraded.state.upgrades.mortarLevel)

        val hit = CombatEngine.resolveMatches(upgraded.state, listOf(group(AmmoColor.RED)))
        assertEquals(14, hit.state.enemies.single().health)
    }

    @Test
    fun purchaseShieldUpgradeIncreasesMaxAndCurrentBaseHp() {
        val state = CombatState(baseHp = 80, maxBaseHp = 100, chips = 40)

        val upgraded = CombatEngine.purchaseUpgrade(state, HangarUpgradeType.SHIELD)
        assertNotNull(upgraded)
        assertEquals(120, upgraded!!.state.maxBaseHp)
        assertEquals(100, upgraded.state.baseHp)
        assertEquals(5, upgraded.state.chips)
    }

    @Test
    fun boostersRequireSufficientChips() {
        val poor = CombatState(baseHp = 70, chips = 10, enemies = listOf(enemy(health = 50)))
        assertNull(CombatEngine.activateAirstrikeBooster(poor))
        assertNull(CombatEngine.activateRepairBooster(poor))

        val rich = poor.copy(chips = 100)
        val strike = CombatEngine.activateAirstrikeBooster(rich)
        assertNotNull(strike)
        assertEquals(60, strike!!.state.chips)

        val repair = CombatEngine.activateRepairBooster(strike.state)
        assertNotNull(repair)
        assertEquals(30, repair!!.state.chips)
        assertEquals(85, repair.state.baseHp)
    }
}
